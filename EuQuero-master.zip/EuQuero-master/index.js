import { AppRegistry } from 'react-native';
import App from './src/App';

console.disableYellowBox = true;

AppRegistry.registerComponent('euquerovantagens', () => App);
